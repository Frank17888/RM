#ifndef __FIR_H__
#define __FIR_H__

void Fir(float Input[],float Output[]);

#define ORDER        5                       //����
#endif
