#ifndef __DELAY_H
#define __DELAY_H

void delay_us(int tim);
void delay_ms(int tim);
void TIM6_Configration(void);
void TIM7_Configration(void);

#endif
