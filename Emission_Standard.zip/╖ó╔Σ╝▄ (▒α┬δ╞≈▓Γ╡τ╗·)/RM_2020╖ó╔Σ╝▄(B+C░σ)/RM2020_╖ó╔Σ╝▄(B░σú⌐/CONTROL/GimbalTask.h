#ifndef __GIMBALTASK_H
#define __GIMBALTASK_H

void Pid_Gimbal_Cal_Rc(void);
void Pid_Gimbal_Pos_Init(void);
void Pid_Gimbal_Speed_Init(void);

#endif
