#ifndef _SOLENOID_H_
#define _SOLENOID_H_

#include "stm32f10x.h"

void SOLENOID_Config(void);
void solenoid_control_Init(void);
void solenoid_reset(void);
void Reload_Task(void);

#endif
