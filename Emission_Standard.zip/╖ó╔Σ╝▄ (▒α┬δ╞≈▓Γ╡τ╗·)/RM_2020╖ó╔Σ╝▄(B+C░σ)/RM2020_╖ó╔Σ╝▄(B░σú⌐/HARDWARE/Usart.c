#include "main.h"
/*
 * USART1 -- TX->PA9 RX->PA10
 * USART2 -- TX->PA2 RX->PA3
 * USART3 -- RX->PB11
 * UART4 --- TX->PC10 RX->PC11
 * UART5 --- TX->PC12 RX->PD2
 * */
uint8_t uart2_TxBuffer[U2_TX_LEN];
uint8_t uart2_RxBuffer[7];
uint8_t uart3_RxBuffer[18];
UART_HandleTypeDef huart2,huart3;

extern unsigned char solenoid_control[10];

void USART_Config(void)
{
	huart2.UART_BASEx = USART2;
	huart3.UART_BASEx = USART3;
	
	{//tim
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2 | RCC_APB1Periph_USART3,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB,ENABLE);
	  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);
	}
	{//GPIO
		UART_GPIO_RX_Config(&huart2,GPIO_Pin_3,GPIOA);
		UART_GPIO_TX_Config(&huart2,GPIO_Pin_2,GPIOA);
		UART_GPIO_RX_Config(&huart3,GPIO_Pin_11,GPIOB);
	}
	{//USART
		UART_Config(&huart3,100000,8,USART_StopBits_1,USART_Parity_Even,USART_Mode_Rx);
		UART_Config(&huart2,115200,8,USART_StopBits_1,USART_Parity_No,USART_Mode_Tx|USART_Mode_Rx);

		USART_ITConfig(USART3,USART_IT_IDLE,ENABLE);
		USART_ITConfig(USART2,USART_IT_IDLE,ENABLE);
		
		USART_Cmd(USART2, ENABLE);
		USART_Cmd(USART3, ENABLE);
		
		USART_DMACmd(USART2,USART_DMAReq_Rx|USART_DMAReq_Tx,ENABLE);
		USART_DMACmd(USART3,USART_DMAReq_Rx,ENABLE);
	}
	{//NVIC
		NVIC_Config(USART2_IRQn, 7, 0);
		NVIC_Config(USART3_IRQn, 5, 0);
	}
	{//DMA
		DMA_Config(DMA1_Channel6,(uint32_t)&huart2.UART_BASEx->DR,(uint32_t)uart2_RxBuffer,DMA_DIR_PeripheralSRC,8,
		           DMA_PeripheralInc_Disable,DMA_MemoryInc_Enable,DMA_PeripheralDataSize_Byte,DMA_MemoryDataSize_Byte,
                   DMA_Mode_Circular,DMA_Priority_VeryHigh,DMA_M2M_Disable);
		DMA_Config(DMA1_Channel7,(uint32_t)&huart2.UART_BASEx->DR,(uint32_t)uart2_TxBuffer,DMA_DIR_PeripheralDST,U2_TX_LEN,
		           DMA_PeripheralInc_Disable,DMA_MemoryInc_Enable,DMA_PeripheralDataSize_Byte,DMA_MemoryDataSize_Byte,
                   DMA_Mode_Normal,DMA_Priority_VeryHigh,DMA_M2M_Disable);
		DMA_Config(DMA1_Channel3,(uint32_t)&huart3.UART_BASEx->DR,(uint32_t)uart3_RxBuffer,DMA_DIR_PeripheralSRC,30,
		           DMA_PeripheralInc_Disable,DMA_MemoryInc_Enable,DMA_PeripheralDataSize_Byte,DMA_MemoryDataSize_Byte,
                   DMA_Mode_Circular,DMA_Priority_VeryHigh,DMA_M2M_Disable);
		//U3 RX
		DMA_Cmd(DMA1_Channel3,ENABLE);    
	}
}
/**
  * @brief  Initializes the USARTx peripheral 
  * @param  USART_BaudRate: 
  *         @arg 9600
  *         @arg 115200
  *         @arg 100000
  * @param  USART_WordLength: 
  *         @arg USART_WordLength_8b                 
  *         @arg USART_WordLength_9b                
  * @param  USART_StopBits: 
  *         @arg USART_StopBits_1                     
  *         @arg USART_StopBits_0_5                 
  *         @arg USART_StopBits_2                   
  *         @arg USART_StopBits_1_5              
  * @param  USART_Parity: 
  *         @arg USART_Parity_No                     
  *         @arg USART_Parity_Even                   
  *         @arg USART_Parity_Odd                    
  * @param  USART_Mode: 
  *         @arg USART_Mode_Rx                      
  *         @arg USART_Mode_Tx    
  *         @arg USART_Mode_Tx|USART_Mode_Rx     
  * @retval None
  */
void UART_Config(UART_HandleTypeDef *uart,uint32_t USART_BaudRate, 
	           uint16_t USART_WordLength,uint16_t USART_StopBits,
               uint16_t USART_Parity,uint16_t USART_Mode)
{
	USART_DeInit(uart->UART_BASEx);
	uart->UARTx.USART_BaudRate = USART_BaudRate;
	uart->UARTx.USART_WordLength = USART_WordLength;
	uart->UARTx.USART_StopBits = USART_StopBits;
	uart->UARTx.USART_Parity = USART_Parity;
	uart->UARTx.USART_Mode = USART_Mode;
	uart->UARTx.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_Init(uart->UART_BASEx,&uart->UARTx);
}
/**
  * @brief  Initializes the GPIOx for usart RX
  * @param  GPIO_PinRx: GPIO_Pin_x,where x can be (0..15) to select the GPIO pin.      
  * @param  GPIORx :GPIOx,where x can be (A..G) to select the GPIO peripheral.
  * @retval None
  */
void UART_GPIO_RX_Config(UART_HandleTypeDef *uart, 
	                uint16_t GPIO_PinRx,GPIO_TypeDef *GPIORx)
{
	uart->UARTx_Rx.GPIO_Pin = GPIO_PinRx;
	uart->UARTx_Rx.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	uart->UARTx_Rx.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIORx,&uart->UARTx_Rx); 
}
/**
  * @brief  Initializes the GPIOx for usart TX
  * @param  GPIO_PinTx: GPIO_Pin_x,where x can be (0..15) to select the GPIO pin.      
  * @param  GPIOTx :GPIOx,where x can be (A..G) to select the GPIO peripheral.
  * @retval None
  */
void UART_GPIO_TX_Config(UART_HandleTypeDef *uart, 
	                uint16_t GPIO_PinTx,GPIO_TypeDef *GPIOTx)
{
	uart->UARTx_Tx.GPIO_Pin = GPIO_PinTx;
	uart->UARTx_Tx.GPIO_Mode = GPIO_Mode_AF_PP;
	uart->UARTx_Tx.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOTx,&uart->UARTx_Tx); 
}

/**
  * @brief  USART2 Interrupt Handler.
  * @param  None      
  * @retval None
  */
void USART2_IRQHandler(void)
{
	if(USART_GetITStatus(USART2,USART_IT_IDLE)!=RESET)  
	{ 
		(void)USART2->SR;
		(void)USART2->DR;	
	} 
}
/**
  * @brief  USART2 TX-DMA��������ж�
  * @param  None      
  * @retval None
  */
void DMA1_Channel7_IRQHandler(void)
{
	if(DMA_GetFlagStatus(DMA1_FLAG_TC7) == SET)
	{
		DMA_Cmd(DMA1_Channel7, DISABLE);
		DMA_SetCurrDataCounter(DMA1_Channel7, U2_TX_LEN);
		DMA_ClearFlag(DMA1_FLAG_TC7);
	}
}
void master2slave_task(void)
{
	//User Code.�˴��޸ķ�������
	uart2_TxBuffer[0] = '!';
	uart2_TxBuffer[1] =solenoid_control[1];
	uart2_TxBuffer[2] =solenoid_control[2];
	uart2_TxBuffer[3] =solenoid_control[3];
	uart2_TxBuffer[4] =solenoid_control[4];
	uart2_TxBuffer[5] =solenoid_control[5];
	uart2_TxBuffer[6] =solenoid_control[6];
	uart2_TxBuffer[7] =solenoid_control[7];
	uart2_TxBuffer[8] =solenoid_control[8];
	uart2_TxBuffer[9] =solenoid_control[9];
	Append_CRC8_Check_Sum(uart2_TxBuffer, 11);
	
	//����U2 TX_DMA
	DMA_Cmd(DMA1_Channel7, ENABLE);
}
/**
  * @brief  USART2 RX-DMA��������ж�
  * @param  None      
  * @retval None
  */
int x3;
unsigned char temp[7], temp_rx[7*2],temp1[7];
void DMA1_Channel6_IRQHandler(void)
{
	short i, n;
	if(DMA_GetFlagStatus(DMA1_FLAG_TC6) == SET)
	{
		x3 ++;
		memcpy(temp_rx + 7, uart2_RxBuffer, 7);
		for(n=0;n<7;n++)
		{
			if(temp_rx[n] == '!' )//
			{
				for(i=0;i<7;i++)
				{
					temp[i] = temp_rx[n+i];
				}
				
				break;
			}
			
		}
		if(temp[0] == '!'&&Verify_CRC8_Check_Sum(temp, 7) == 1)
		{
				for(n=0;n<7;n++)
			{
				temp1[n] = temp[n];
			}
		}
		memcpy(temp_rx, temp_rx + 7, 7);
		DMA_ClearFlag(DMA1_FLAG_TC6);
}
}

void USART3_IRQHandler(void)
{
	static int DATA_LENGTH=0;
	if (USART_GetITStatus(USART3, USART_IT_IDLE) != RESET)    //��ʱ�ж�
	{
		(void)USART3->SR;
		(void)USART3->DR;	
		DMA_Cmd(DMA1_Channel3,DISABLE);
		DATA_LENGTH = RX_USART3_BUFFER - DMA_GetCurrDataCounter(DMA1_Channel3);
		if(DATA_LENGTH==18)
		{
			remote_receive(uart3_RxBuffer);
			Discnect_Flag.Rc_Cnt = 0;
			Discnect_Flag.Rc_Connect = 0;
		}
		DMA_SetCurrDataCounter(DMA1_Channel3,RX_USART3_BUFFER);	
		DMA_Cmd(DMA1_Channel3,ENABLE);
    }	
}
