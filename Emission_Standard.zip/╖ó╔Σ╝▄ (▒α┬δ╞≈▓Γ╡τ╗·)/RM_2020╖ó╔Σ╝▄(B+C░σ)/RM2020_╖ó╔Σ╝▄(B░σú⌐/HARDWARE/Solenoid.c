#include "main.h"

unsigned char solenoid_control[10];
u8 Solenoid_Power_Flag = 1;
/**
  * @brief  Solenoid configuration.
  * @param  None
  * @retval None
  */
void SOLENOID_Config(void)
{
	GPIO_InitTypeDef gpio;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	gpio.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	gpio.GPIO_Mode = GPIO_Mode_Out_PP;
	gpio.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &gpio);

	GPIO_ResetBits(GPIOA, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);   			//Turn off all the solenoids.
}

void solenoid_control_Init(void)
{
	solenoid_control[1] = 0;//��������
	solenoid_control[2] = 0;//��ת����
	solenoid_control[3] = 0;//ȡ����
	solenoid_control[4] = 0;//��������
	solenoid_control[5] = 0;//�Զ�ȡ��
	solenoid_control[6] = 0;//��Ļ����
	solenoid_control[7] = 0;//̧��
	solenoid_control[8] = 0;//����
	solenoid_control[9] = 0;//ȡ����־λ
}

void solenoid_reset(void)
{

}
/**
  * @brief  ��������
  * @param  None
  * @retval None
  */
void Reload_Task(void)
{
	if(Solenoid_Power_Flag == 1)
	{
		
	}
	else
	{
		
	}
}

