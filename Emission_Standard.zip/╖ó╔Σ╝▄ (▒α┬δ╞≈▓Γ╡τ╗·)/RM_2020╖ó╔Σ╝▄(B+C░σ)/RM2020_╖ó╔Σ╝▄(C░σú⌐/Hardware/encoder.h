#ifndef _ENCODER_H_
#define _ENCODER_H_

void ENCODER_Configuration(void);
short Encoder_read(void);
#endif
