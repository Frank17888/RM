#ifndef _USART2_H_
#define _USART2_H_

#define GYRO_BUF_SIZE 18
void USART2_Configuration(void);

#endif
