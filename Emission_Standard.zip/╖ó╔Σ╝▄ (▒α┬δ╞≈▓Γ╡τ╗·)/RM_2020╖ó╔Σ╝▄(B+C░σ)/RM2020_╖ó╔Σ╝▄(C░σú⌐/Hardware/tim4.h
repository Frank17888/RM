#ifndef _TIM4_H_
#define _TIM4_H_

void simulateSwitch(u8 state);
void Tim4_Configuration(void);

#endif
