#ifndef _LASER_H_
#define _LASER_H_

void LASER_Configuration(void);

#endif
