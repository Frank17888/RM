#ifndef _SOLENOIDSW_H_
#define _SOLENOIDSW_H_


#include "stm32f10x.h"

void solenoid_config(void);

#endif
