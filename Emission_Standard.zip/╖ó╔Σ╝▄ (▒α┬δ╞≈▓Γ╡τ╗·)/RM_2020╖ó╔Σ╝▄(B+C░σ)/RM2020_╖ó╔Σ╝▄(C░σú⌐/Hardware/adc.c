#include "main.h"
#include "adc.h"


void  Adc_Init(void)
{    
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
		
	GPIO_SetBits(GPIOA,GPIO_Pin_0);
	GPIO_SetBits(GPIOC,GPIO_Pin_15);

}				  
unsigned char get_adc[7],get_adc1[7];
extern int switchflag; 

void  Get_Adc(void)   
{
	 int get_adc_sum = 0;
	 int get_adc_sum1 = 0;
	 u8 num,num1;
	 
	for(num = 0;num<7;num++)
	{
		get_adc[num] = GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13);
		get_adc_sum += get_adc[num];
	}
	
	for(num1 = 0;num1<7;num1++)
	{
		get_adc1[num1] = GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_14);
		get_adc_sum1 += get_adc1[num1];
	}
	if(get_adc_sum == 0&&get_adc_sum1 == 0)
	   switchflag = 0;
	else 
		 switchflag = 1;

}
