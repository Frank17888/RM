#ifndef __DELAY_H
#define __DELAY_H	
#include "main.h"
void TIM3Init(void);
void TIM2Init(void);
//void TIM3Init(void);
void delay_ms(int tim);
void delay_us(int tim);
#endif 
