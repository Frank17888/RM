#ifndef _ADC_H
#define _ADC_H

#include "stm32f10x.h"

void Get_Adc(void);
void  Adc_Init(void);

#endif
