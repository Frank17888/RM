#ifndef _USART1_H_
#define _USART1_H_


void USART3_Configuration(void);
void master2slave_task(void);

#endif
