#include "main.h"
#include "tim4.h"

int simulateCnt;
/**
  * @brief  tim4 config
  * @param  None
  * @retval None
  */
void Tim4_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure; 
	TIM_TimeBaseInitTypeDef   tim;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	tim.TIM_Prescaler = 4-1;//21MHz
	tim.TIM_CounterMode = TIM_CounterMode_Up;
	tim.TIM_Period = 18000-1;//2us
	tim.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInit(TIM4,&tim);
	
	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;	  
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;	
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM4, DISABLE);
	
	TIM_ClearFlag(TIM4, TIM_FLAG_Update);
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);
	
	IN1_H;
	IN2_L;
}
/**
  * @brief  
  * @param  
  * @retval None
  */

void TIM4_IRQHandler(void)
{
   if(TIM_GetITStatus(TIM4, TIM_IT_Update)==SET)
	{
		simulateCnt++;
		if(simulateCnt == 200)
		{
			TIM_Cmd(TIM4, DISABLE);
			IN1_L;
			IN2_L;
      simulateCnt = 0;
		}
	}
	TIM_ClearITPendingBit(TIM4, TIM_IT_Update);  
}	

void simulateSwitch(u8 state)
{
	
		
		if(state == 0)
		{
			IN1_L;
			IN2_L;
		}
		else if(state == 1)
		{
			IN1_H;
			IN2_L;
		}
		else if(state == 2)
		{
			IN1_L;
			IN2_H;
		}
		else if(state == 3)
		{
			IN1_H;
			IN2_H;
		}
		TIM_Cmd(TIM4, ENABLE); 
	
	}

