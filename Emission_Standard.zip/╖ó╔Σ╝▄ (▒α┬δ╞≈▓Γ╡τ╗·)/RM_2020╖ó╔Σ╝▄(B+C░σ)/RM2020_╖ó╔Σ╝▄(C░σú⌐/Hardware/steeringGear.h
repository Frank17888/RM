#ifndef _STEERINGGEAR_H_
#define _STEERINGGEAR_H_

void SteeringGear_Configuration(void);
void SteeringGear_Set1(int position);
void SteeringGear_Set2(int position);

#endif
