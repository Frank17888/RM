#include "main.h"



unsigned char usart_rx[11];
unsigned char usart_tx[7];
extern int get_bullet_flag;
extern int switchflag;

void USART3_Configuration(void)
{
	USART_InitTypeDef usart;
	GPIO_InitTypeDef  gpio;
	NVIC_InitTypeDef  nvic;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_USART1,ENABLE);
	
	gpio.GPIO_Pin = GPIO_Pin_7;
	gpio.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	gpio.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&gpio);

	gpio.GPIO_Pin = GPIO_Pin_6;
	gpio.GPIO_Mode = GPIO_Mode_AF_PP;
	gpio.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&gpio);
	
	USART_DeInit(USART1);
	usart.USART_BaudRate = 115200;
	usart.USART_WordLength = USART_WordLength_8b;
	usart.USART_StopBits = USART_StopBits_1;
	usart.USART_Parity = USART_Parity_No ;
	usart.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	usart.USART_HardwareFlowControl = USART_HardwareFlowControl_None;   
	USART_Init(USART1, &usart);
	USART_Cmd(USART1, ENABLE);

	
	USART_DMACmd(USART1, USART_DMAReq_Rx, ENABLE); 
	//����dma
	{
		DMA_InitTypeDef  dma;
		
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
		
		DMA_DeInit(DMA1_Channel5);
		
		dma.DMA_PeripheralBaseAddr = (uint32_t)&(USART1->DR);
		dma.DMA_MemoryBaseAddr = (uint32_t)usart_rx;
		dma.DMA_DIR = DMA_DIR_PeripheralSRC;
		dma.DMA_BufferSize = 11;
		dma.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
		dma.DMA_MemoryInc = DMA_MemoryInc_Enable;
		dma.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
		dma.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
		dma.DMA_Mode = DMA_Mode_Circular;
		dma.DMA_Priority = DMA_Priority_VeryHigh;
		dma.DMA_M2M = DMA_M2M_Disable;
		
		DMA_Init(DMA1_Channel5, &dma);
		DMA_ITConfig(DMA1_Channel5,DMA_IT_TC,ENABLE);
		DMA_Cmd(DMA1_Channel5, ENABLE);
		
		nvic.NVIC_IRQChannel = DMA1_Channel5_IRQn;
		nvic.NVIC_IRQChannelPreemptionPriority = 0;
		nvic.NVIC_IRQChannelSubPriority = 1;
		nvic.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&nvic);
	}
	//����dma
	USART_DMACmd(USART1, USART_DMAReq_Tx, ENABLE); 
	{
  	DMA_InitTypeDef  dma;
		
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
		
		DMA_DeInit(DMA1_Channel4);
		
		dma.DMA_PeripheralBaseAddr = (uint32_t)&(USART1->DR);
		dma.DMA_MemoryBaseAddr = (uint32_t)usart_tx;
		dma.DMA_DIR = DMA_DIR_PeripheralDST;
		dma.DMA_BufferSize = 7;
		dma.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
		dma.DMA_MemoryInc = DMA_MemoryInc_Enable;
		dma.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
		dma.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
		dma.DMA_Mode = DMA_Mode_Normal;
		dma.DMA_Priority = DMA_Priority_VeryHigh;
		dma.DMA_M2M = DMA_M2M_Disable;
		
		DMA_Init(DMA1_Channel4, &dma);
		DMA_ITConfig(DMA1_Channel4,DMA_IT_TC,ENABLE);
		DMA_Cmd(DMA1_Channel4, ENABLE);
		
		nvic.NVIC_IRQChannel = DMA1_Channel4_IRQn;
		nvic.NVIC_IRQChannelPreemptionPriority = 0;
		nvic.NVIC_IRQChannelSubPriority = 0;
		nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);
	}
}

int is_tx2_connect_cnt;
int x3;
unsigned char temp[11], temp_rx[11*2],temp1[11];

void DMA1_Channel5_IRQHandler(void)
{
	short i, n;
	if(DMA_GetFlagStatus(DMA1_FLAG_TC5) == SET)
	{
		x3 ++;
		memcpy(temp_rx + 11, usart_rx, 11);
		for(n=0;n<11;n++)
		{
			if(temp_rx[n] == '!' )//
			{
				for(i=0;i<11;i++)
				{
					temp[i] = temp_rx[n+i];
				}
				
				break;
			}
			
		}
		if(temp[0] == '!'&&Verify_CRC8_Check_Sum(temp, 11) == 1)
		{
				for(n=0;n<11;n++)
			{
				temp1[n] = temp[n];
			}
		}
		memcpy(temp_rx, temp_rx + 11, 11);
		DMA_ClearFlag(DMA1_FLAG_TC5);
		
	  master2slave_task();
	}
}
void DMA1_Channel4_IRQHandler(void)
{
	if(DMA_GetFlagStatus(DMA1_FLAG_TC4) == SET)
	{
		DMA_Cmd(DMA1_Channel4, DISABLE);
		DMA_SetCurrDataCounter(DMA1_Channel4, 7);
		DMA_ClearFlag(DMA1_FLAG_TC4);
	}
}
int get_bullet_state_flag;
void master2slave_task(void)
{
	//User Code.�˴��޸ķ�������
	usart_tx[0] = '!';
	usart_tx[1] =0;
	usart_tx[2] =1;
	usart_tx[3] =switchflag;
	usart_tx[4] =get_bullet_state_flag;
	usart_tx[5] =get_bullet_flag;
	
	
	Append_CRC8_Check_Sum(usart_tx, 7);
	
	//����U2 TX_DMA
	DMA_Cmd(DMA1_Channel4, ENABLE);
}
