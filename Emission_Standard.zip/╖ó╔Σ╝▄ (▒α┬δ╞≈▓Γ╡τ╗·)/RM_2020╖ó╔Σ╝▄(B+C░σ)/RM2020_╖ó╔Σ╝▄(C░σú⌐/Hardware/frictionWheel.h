#ifndef _FRICTIONWHEEL_H_
#define _FRICTIONWHEEL_H_

void FrictionWheel_Configuration(void);
void FrictionWheel_Set(int speed);

#endif
