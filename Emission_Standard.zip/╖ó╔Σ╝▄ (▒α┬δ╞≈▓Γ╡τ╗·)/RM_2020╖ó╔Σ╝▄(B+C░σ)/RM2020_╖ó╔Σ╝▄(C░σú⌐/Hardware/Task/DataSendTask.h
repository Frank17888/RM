#ifndef _DATASENDTASK_H
#define _DATASENDTASK_H

void CAN_SendTask(void);

#endif
