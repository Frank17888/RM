#include "main.h" 

int change_enable,i;
int i_last;
int ms50, tick50;
int get_bullet_flag;
int switchflag;

int main(void)
{
 	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	TIM2Init();
	TIM3Init();
	delay_ms(250);
	system_Config();
	while(1)
	{

	}
}


void system_Config(void)
{ 
  
	LED_Configuration();       //��
	USART3_Configuration();    //��
  solenoid_config();
}


